
function L = SLRGA_sigma(X,D,para)

k = para.k;

lamda = para.lamda;

% lamda  can be tuned from [0.1,10,1000];
% X is the training set with m*n, where n is the number of observations
% D is the initialized reweighted matrix with n*k, Di is reweighted vector 

[Dim, n] = size(X);

ek = ones(k,1);

A = spalloc(n*k,n*k,5*n*k);

S = spalloc(n,n*k,5*n*k);

for i = 1:n
    Di = diag(D(i,:));
    Hi = eye(k) - (ek*ek'*Di)/(ek'*Di*ek);
    
    lidx = (i-1)*k+1:(i-1)*k+k;

    dis = repmat(X(:,i),1,n) - X;

    dis = sum(dis.*dis);

    [~, nnidx] = sort(dis);

    Xi = X(:,nnidx(1:k));
    
    Ni = Hi'*Di*Hi;    
    if  Dim > k % more stable, because the Di^0.5, reduce the influence of square
        Gi = Di^0.5*(eye(k) - (ek*ek'*Di)/(ek'*Di*ek));
        Ai = lamda*Gi'*inv(lamda*eye(k) + Gi*(Xi'*Xi)*Gi'+eps)*Gi;
    else
        Ai = Ni - Ni*Xi'*inv(lamda*eye(Dim) + Xi*Ni*Xi'+eps)*Xi*Ni;
    end;

    A(lidx, lidx) = Ai;
    S(nnidx(1:k),lidx) = eye(k);
    %L = L + S(:,lidx)*Ai*S(:,lidx)';
    
end

L = lamda*S*A*S';


