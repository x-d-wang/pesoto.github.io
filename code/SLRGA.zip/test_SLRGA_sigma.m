clear all;
%X \in d x n
%normalized data to [-1,1]
X = mapminmax(fea);
Y = gnd;
c = max(Y);
para.k = 5;

lamda = 1000; % should be turned or judged first by the character of dataset.
para.lamda = lamda;

sigma = 10e-5;

N = size(X,2);
d = size(X,1);
D = repmat(ones(1,k),N,1)*1;
D1 = repmat(ones(1,k),N,1)*1;
ek = ones(k,1);
nITER = 10;
obj = zeros(nITER,1);
for iter = 1:nITER
L_s = SLRGA_sigma(X,D,para);
%update F
[evec_s,eval_s] = eigs_wxd(L_s);
F_s = evec_s(:,1:c);
for i = 1:N
    dis = repmat(X(:,i),1,N) - X;
    dis = sum(dis.*dis);
    [dumb, nnidx] = sort(dis);
    Xi = X(:,nnidx(1:k));

    Fi = F_s(nnidx(1:k),:);
    Di = diag(D(i,:));
    Hi = eye(k) - (ek*ek'*Di)/(ek'*Di*ek);
    Di2 = Di^0.5;%reduce the infulence of square of distance
    Vi = Xi*Hi'*Di2*inv(lamda*eye(k) + Di2*Hi*Xi'*Xi*Hi'*Di2)*Di2*Hi*Fi; 
    %Vi = inv( Xi*Hi'*Di*Hi*Xi' + lamda*eye(d)+eps)*Xi*Hi'*Di*Hi*Fi;
    bi = (( Fi' - Vi'*Xi)*Di*ek)/(ek'*Di*ek);
    for j = 1:k
        e = norm(Vi'*Xi(:,j) + bi - Fi(j,:)');
        D(i,j) = (1+sigma)/2*(e+2*sigma)./((e+sigma).^2);
        obj(iter) = obj(iter) + sum((1+sigma)*(e.^2)./(e+sigma));
    end
    %objective function
    obj(iter) = obj(iter) + lamda*norm(Vi,'fro')^2;
end


