function [obj,G,Q] = FAKM(data,Red_dim,nclass,lambda,sigma)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% data: the original data, Each column vector of fea is a
%%%% data point
%%%% lambda,sigma: parameters for FAKM
%%%% Red_dim: the dimensionality of subspace
%%%% nclass: number of clusters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% author: xdwang
%%%% e-mail: xdwangjsj@xmut.edu.cn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nFea, nSmp] = size(data);
intermax = 20;

%%%% Centralization %%%%
data = data-repmat(mean(data,2),1,size(data,2)); 

%%%% Using Pca to initialize Q  %%%%
data = full(data);
[u d v] = svds(data,nclass);
d = diag(d); [temp idx] = sort(d,'descend');
Q = u(:,idx(1:nclass-1));
XW = data'*Q;         
clear u; clear v; clear d;

%Randomly initialize the embeded class indicator matrix, for data with extreme high dimensionality 
%XW = rand(nSmp,nclass);
StartInd = randsrc(nSmp,1,1:nclass);
[res_km,sumd,center] = kmeans_ldj(XW, StartInd);
G = zeros(nSmp,nclass);
for cn = 1:nclass
    nc = sum(res_km==cn);
    G((res_km==cn),cn) = 1;
end
clear res_km; clear sumd; clear center;
%%%%%%%%% Fix G to update Q and F   
temp = diag(1./sqrt((diag(G'*G)+eps)));

temp2 =temp^0.5;
M = data*sparse(G)*temp2;
diag_pnts = (1-lambda)*sum(data.^2,2) + lambda*sum(M.^2,2);
[d,idx] = sort(diag_pnts,'descend');

Q = zeros(nFea,Red_dim);
Q(sub2ind(size(Q),idx(1:Red_dim),[1:Red_dim]')) =1;
F = sparse(Q')*data*G*temp;
d = ones(nSmp,1);

%%%% Main Run
for ii=1:intermax
    D = spdiags(d,0,nSmp,nSmp);
    %%%%%%%%% Fix Q to compute F and G %%%%
    XW = data'*sparse(Q);    %%%% XW is the low dimensional embedding, nSmp*Nfea
    
   %%%% Comparision rule %%%%
    [index,sumd,center] = kmeans_ldj_l21(XW, D,F');
    error = sum(sumd);
    indicator = 0;
    times = 1;
    while indicator == 0 && times<20
        StartInd = randsrc(nSmp,1,1:nclass);
        [res_km,sumd,center] = kmeans_ldj_l21(XW,D, StartInd);
        obj_km = sum(sumd); 
        if obj_km<error
            indicator = 1; 
        end
        res_km_all(:,times) = res_km;
        obj_km_all(times) = obj_km;
        times = times+1;
    end
    if times == 20
        res_km = index;
    end
    
    %%%% Initialize G %%%%
    G = zeros(nSmp,nclass);
    for cn = 1:nclass
        nc = sum(res_km==cn);
        G((res_km==cn),cn) = 1;
    end
  
    %%%% Fix G to update Q and F %%%%
    GT_D_G = diag(1./diag(sparse(G')*sparse(D)*sparse(G)));
    Sqrt_GT_D_G =GT_D_G^0.5;
    M = data*sparse(D)*sparse(G)*Sqrt_GT_D_G;
    sqrt_D = spdiags(sqrt(d),0,nSmp,nSmp);
    %%%% diagonal points of (St-lambda*Sw), the quick version %%%%
    diag_pnts = sum(data.^2,2) - lambda*sum((data*sqrt_D).^2,2) + lambda*sum(M.^2,2);
    %%%%large_ds means the large values of tr Q'*(St-lambda*Sw)Q %%%%
    [~,idx] = nth_element(-diag_pnts,Red_dim); % select nth largest elements
    
    Q = zeros(nFea,Red_dim);
    Q(sub2ind(size(Q),idx(1:Red_dim),[1:Red_dim]')) =1;
    
    F = sparse(Q')*data*sparse(D)*sparse(G)*GT_D_G;
    E = data'*sparse(Q)-sparse(G)*F';
    e = sqrt(sum(E.*E,2));
    
    obj(ii) = sum(sum((sparse(Q')*data).^2,2))-lambda*sum((1+sigma)*(e.^2)./(e+sigma));
    
    d = (1+sigma)/2*(e+2*sigma)./((e+sigma).^2);
    %%%% Compute the function values %%%%
    if(ii > 1 && abs(obj(ii)-obj(ii-1))/obj(ii) < 1e-3)
        break;
    end
end

end
