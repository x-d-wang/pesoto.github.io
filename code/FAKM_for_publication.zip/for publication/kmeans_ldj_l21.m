function [Ind,sumd,center] = kmeans_ldj_l21(M,D,StartIndMeanK)
% each row is a data point
% D \in n x n , is a diagnoal matrix 
[nSample, nFeature] = size(M);
if isscalar(StartIndMeanK)
%     t = randperm(nSample);
%     StartIndMeanK = t(1:StartIndMeanK);
    StartIndMeanK = randsrc(nSample,1,1:StartIndMeanK);
end
if isvector(StartIndMeanK)
    K = length(StartIndMeanK);
    if K == nSample
        K = max(StartIndMeanK);
        means = zeros(K,nFeature);
        for ii=1:K
            means(ii,:) = mean(M(find(StartIndMeanK==ii),:),1);
        end
    else
        means = zeros(K,nFeature);
        for ii=1:K
            means(ii,:) = M(StartIndMeanK(ii),:);
        end
    end
else
    K = size(StartIndMeanK,1);
    means = StartIndMeanK;
end
center = means;
M2 = sum(M.*M, 2)';
twoMp = 2*M';
M2b = repmat(M2,[K,1]);
Center2 = sum(center.*center,2);Center2a = repmat(Center2,[1,nSample]);[dist, Ind] = min(abs((M2b + Center2a - center*twoMp)*D)); % by wxd 2016.11.26
Ind2 = Ind;
sumd = sum(dist);


